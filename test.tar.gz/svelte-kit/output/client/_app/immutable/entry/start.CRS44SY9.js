import{e as a}from"../chunks/entry.BeEOob_1.js";export{a as start};
