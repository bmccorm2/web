import { c as create_ssr_component, a as subscribe, e as each, d as escape, b as add_attribute } from "./ssr.js";
import { p as page } from "./stores.js";
const CarSource = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  let { cars } = $$props;
  if ($$props.cars === void 0 && $$bindings.cars && cars !== void 0)
    $$bindings.cars(cars);
  $$unsubscribe_page();
  return `<div class="text-center my-2">${each(cars, (car) => {
    return `<a href="${"/consumption/" + escape(car.id, true)}"${add_attribute(
      "class",
      `text-pink-600 text-xl font-bold px-3
      ${parseInt($page.params.id) === car.id ? "opacity-100 underline" : "opacity-60"}
      `,
      0
    )}>${escape(car.displayName)}</a>`;
  })}</div>`;
});
export {
  CarSource as C
};
