const GET_YIELDS = `
	{
		yields {
			id
			effectiveDate
			oneMonth
			threeMonth
			sixMonth
			oneYear
			twoYear
			threeYear
			fiveYear
			sevenYear
			tenYear
			twentyYear
			thirtyYear
		}
	}
`;
const GET_CAR_DETAILS = `
	query CarDetails($carId: Int!) {
		cars(isOwned: false) {
			id
			displayName
		}
		carDetails(carId: $carId) {
			url
			price
			miles
			displayName
			year
			distance
			effectiveDate
		}
	}
`;
export {
  GET_CAR_DETAILS as G,
  GET_YIELDS as a
};
