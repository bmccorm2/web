import { c as create_ssr_component, b as add_attribute, d as escape } from "./ssr.js";
const Card = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { header = "default title" } = $$props;
  let { isSuccess = false } = $$props;
  if ($$props.header === void 0 && $$bindings.header && header !== void 0)
    $$bindings.header(header);
  if ($$props.isSuccess === void 0 && $$bindings.isSuccess && isSuccess !== void 0)
    $$bindings.isSuccess(isSuccess);
  return `<div class="w-full font-bold rounded-lg bg-slate-800 border-4 border-slate-400"><div${add_attribute(
    "class",
    `rounded-b-lg uppercase p-4 text-2xl text-center  ${isSuccess ? "bg-emerald-700" : "bg-gradient-to-b from-sky-800 to-sky-700"}`,
    0
  )}>${escape(header)}</div> ${slots.default ? slots.default({}) : ``}</div>`;
});
export {
  Card as C
};
