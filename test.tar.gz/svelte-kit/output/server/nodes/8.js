import * as universal from '../entries/pages/life/_page.ts.js';

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/life/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/life/+page.ts";
export const imports = ["_app/immutable/nodes/8.C17pSShE.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/index.BXCylPL7.js"];
export const stylesheets = ["_app/immutable/assets/8.LMR_jOKV.css"];
export const fonts = [];
