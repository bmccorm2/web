import * as universal from '../entries/pages/snake/_page.ts.js';

export const index = 9;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/snake/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/snake/+page.ts";
export const imports = ["_app/immutable/nodes/9.IEiD8FYf.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/index.BXCylPL7.js"];
export const stylesheets = ["_app/immutable/assets/9.BzznCT2j.css"];
export const fonts = [];
