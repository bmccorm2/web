import * as server from '../entries/pages/cars/_id_/_page.server.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/cars/_id_/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/cars/[id]/+page.server.ts";
export const imports = ["_app/immutable/nodes/5.DFuqbssR.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/index.BXCylPL7.js","_app/immutable/chunks/CarSource.lhW85hXJ.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/stores.ByZWx6Ab.js","_app/immutable/chunks/entry.BeEOob_1.js","_app/immutable/chunks/index.DW7IqcQf.js","_app/immutable/chunks/chart.kjNuw3eb.js"];
export const stylesheets = ["_app/immutable/assets/5.CTz3gDx5.css"];
export const fonts = [];
