import * as server from '../entries/pages/books/modify/__id__/_page.server.ts.js';

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/books/modify/__id__/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/books/modify/[[id]]/+page.server.ts";
export const imports = ["_app/immutable/nodes/4.B8K17qtP.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/index.BXCylPL7.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/Icon.CE6fvTCk.js","_app/immutable/chunks/Card.DLni96uo.js","_app/immutable/chunks/index.DW7IqcQf.js","_app/immutable/chunks/entry.BeEOob_1.js","_app/immutable/chunks/Toaster.VxGo1d4b.js","_app/immutable/chunks/index.D7JnYTLA.js","_app/immutable/chunks/stores.ByZWx6Ab.js","_app/immutable/chunks/trash-2.Df2BMPkW.js"];
export const stylesheets = ["_app/immutable/assets/4.DvvOsndP.css","_app/immutable/assets/Toaster.CqNDpgoD.css"];
export const fonts = [];
