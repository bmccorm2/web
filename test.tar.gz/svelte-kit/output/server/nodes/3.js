import * as server from '../entries/pages/books/_page.server.ts.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/books/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/books/+page.server.ts";
export const imports = ["_app/immutable/nodes/3.DWzVZLCG.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/index.BXCylPL7.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/index.D7JnYTLA.js","_app/immutable/chunks/Icon.CE6fvTCk.js","_app/immutable/chunks/index.DW7IqcQf.js","_app/immutable/chunks/trash-2.Df2BMPkW.js"];
export const stylesheets = [];
export const fonts = [];
