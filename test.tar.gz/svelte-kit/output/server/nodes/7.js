import * as server from '../entries/pages/consumption/input/_page.server.ts.js';

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/consumption/input/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/consumption/input/+page.server.ts";
export const imports = ["_app/immutable/nodes/7.d2TGh_Gb.js","_app/immutable/chunks/scheduler.7fX07wj1.js","_app/immutable/chunks/index.BXCylPL7.js","_app/immutable/chunks/Icon.CE6fvTCk.js","_app/immutable/chunks/each.MfJNF0pi.js","_app/immutable/chunks/Toaster.VxGo1d4b.js","_app/immutable/chunks/index.DW7IqcQf.js","_app/immutable/chunks/index.D7JnYTLA.js","_app/immutable/chunks/stores.ByZWx6Ab.js","_app/immutable/chunks/entry.BeEOob_1.js","_app/immutable/chunks/Card.DLni96uo.js"];
export const stylesheets = ["_app/immutable/assets/Toaster.CqNDpgoD.css"];
export const fonts = [];
