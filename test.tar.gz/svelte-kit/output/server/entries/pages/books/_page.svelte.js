import { c as create_ssr_component, v as validate_component, d as escape, b as add_attribute, e as each } from "../../../chunks/ssr.js";
import { B as Button } from "../../../chunks/index3.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { T as Trash2, S as Star } from "../../../chunks/trash-2.js";
const Pencil_line = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["path", { "d": "M12 20h9" }],
    [
      "path",
      {
        "d": "M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"
      }
    ],
    ["path", { "d": "m15 5 3 3" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "pencil-line" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const PencilLine = Pencil_line;
const Book = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { bookDetails } = $$props;
  const { title, author, rating, pages, isFiction, id, review } = bookDetails;
  if ($$props.bookDetails === void 0 && $$bindings.bookDetails && bookDetails !== void 0)
    $$bindings.bookDetails(bookDetails);
  return `<div class="rounded-lg border-2 border-teal-500 bg-slate-800 p-4"><div class="mb-2 flex justify-between"><div class="flex content-center gap-3"> <div class="text-3xl font-bold underline">${escape(title)}</div></div>  <div class="flex gap-3"><a href="${"books/modify/" + escape(id, true)}">${validate_component(PencilLine, "PencilLine").$$render($$result, { class: "h-4- w-4" }, {}, {})}</a> <form action="?/deleteBook" method="post"><input type="hidden" name="id"${add_attribute("value", id, 0)}> <button>${validate_component(Trash2, "Trash2").$$render($$result, { class: "h-4- w-4" }, {}, {})}</button></form></div></div>  <div class="mb-2 flex justify-between"><div class="self-center text-xs text-slate-400">By ${escape(author)}</div> <div class="flex gap-4"><div class="self-center rounded-full bg-blue-700 px-2 py-1 text-xs">${escape(pages)} pages</div> <div class="self-center rounded-full bg-gray-500 px-2 py-1 text-xs">${escape(isFiction ? "Fiction" : "Non-Fiction")}</div></div></div>  <div class="mb-2 flex content-center gap-2">${each([1, 2, 3, 4, 5], (rate) => {
    let colored = rate <= rating;
    return ` ${validate_component(Star, "Star").$$render(
      $$result,
      {
        strokeWidth: 0,
        fill: colored ? "gold" : ""
      },
      {},
      {}
    )}`;
  })}</div>  <div class="mb-3">${review ? `<div>${escape(review)}</div>` : `<div data-svelte-h="svelte-1n955gt">No Review for this book.</div>`}</div>  <div class="flex justify-between"><div class="flex gap-2"><div class="self-center text-xs text-gray-500" data-svelte-h="svelte-3u5fut">Genres</div> ${each(bookDetails.genres, ({ description }) => {
    return `<div class="place-self-start rounded-xl bg-purple-700 px-2 py-1 text-xs">${escape(description)} </div>`;
  })}</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  return `<div class="container mx-auto"><div class="flex justify-center">${validate_component(Button, "Button").$$render(
    $$result,
    {
      variant: "link",
      href: "/books/modify",
      class: "me-2 mt-4 w-1/2 rounded-lg bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-gradient-to-br focus:outline-none focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800"
    },
    {},
    {
      default: () => {
        return `Add a New Book`;
      }
    }
  )}</div> <hr class="my-4"> <div class="grid grid-cols-2 gap-4">${each(data.books, (bookDetails) => {
    return `${validate_component(Book, "Book").$$render($$result, { bookDetails }, {}, {})}`;
  })}</div></div>`;
});
export {
  Page as default
};
