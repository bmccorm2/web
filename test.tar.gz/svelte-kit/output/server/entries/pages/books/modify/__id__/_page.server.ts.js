import { e as error, f as fail, r as redirect } from "../../../../../chunks/index.js";
import { s as superValidate } from "../../../../../chunks/superValidate.js";
import { a as zod, b as bookSchema, g as genreSchema } from "../../../../../chunks/zod.js";
import { c as client, b as GET_GENRES, d as GET_BOOK, U as UPDATE_BOOK, D as DELETE_BGA, I as INSERT_BGA, e as INSERT_BOOK, f as INSERT_GENRE, g as DELETE_GENRE } from "../../../../../chunks/queries.js";
import { s as serializeBooks } from "../../../../../chunks/utilities.js";
const load = async ({ params }) => {
  const id = params.id ? parseInt(params.id) : -1;
  try {
    const rs = await client.batch(
      [
        GET_GENRES,
        {
          sql: GET_BOOK,
          args: { id }
        }
      ],
      "read"
    );
    const genres = rs[0].rows;
    const book = serializeBooks(rs[1].rows)[0];
    const form = await superValidate(book, zod(bookSchema));
    const genreForm = await superValidate(zod(genreSchema));
    return { genres, form, genreForm };
  } catch (e) {
    error(505, e.message);
  }
};
const actions = {
  modify: async (event) => {
    const form = await superValidate(event, zod(bookSchema));
    if (!form.valid)
      return fail(400, { form });
    if (form.data.id) {
      const transaction = await client.transaction("write");
      await transaction.execute({
        sql: UPDATE_BOOK,
        args: {
          id: form.data.id,
          title: form.data.title,
          author: form.data.author,
          pages: form.data.pages,
          publishDate: form.data.publishDate,
          isFiction: form.data.isFiction,
          review: form.data.review,
          rating: form.data.rating
        }
      });
      await transaction.execute({
        sql: DELETE_BGA,
        args: { id: form.data.id }
      });
      form.data.genres.forEach(async (e) => {
        await transaction.execute({
          sql: INSERT_BGA,
          args: {
            id: form.data.id,
            genreId: e.id
          }
        });
      });
      await transaction.commit();
      redirect(301, "/books");
    } else {
      const transaction = await client.transaction("write");
      const rs = await transaction.execute({
        sql: INSERT_BOOK,
        args: {
          title: form.data.title,
          author: form.data.author,
          pages: form.data.pages,
          publishDate: form.data.publishDate,
          isFiction: form.data.isFiction,
          review: form.data.review,
          rating: form.data.rating
        }
      });
      const id = Number(rs.lastInsertRowid);
      form.data.genres.forEach(async (e) => {
        await transaction.execute({
          sql: INSERT_BGA,
          args: {
            id,
            genreId: e.id
          }
        });
      });
      await transaction.commit();
      redirect(301, "/books");
    }
  },
  insertGenre: async (event) => {
    const form = await superValidate(event, zod(genreSchema));
    if (!form.valid)
      return fail(400, { form });
    const { description } = form.data;
    await client.execute({
      sql: INSERT_GENRE,
      args: { description }
    });
    return { form };
  },
  deleteGenre: async ({ request }) => {
    const { id: t } = Object.fromEntries(await request.formData());
    const id = parseInt(t);
    await client.execute({
      sql: DELETE_GENRE,
      args: { id }
    });
    return { success: "true" };
  }
};
export {
  actions,
  load
};
