import { f as createEventDispatcher, s as setContext, g as getContext, c as create_ssr_component, h as compute_rest_props, a as subscribe, i as spread, j as escape_object, b as add_attribute, e as each, d as escape, v as validate_component, k as escape_attribute_value, l as set_store_value } from "../../../../../chunks/ssr.js";
import { C as Card } from "../../../../../chunks/Card.js";
import { d as derived, w as writable } from "../../../../../chunks/index2.js";
import "../../../../../chunks/stores.js";
import { z as zodClient, g as genreSchema, b as bookSchema } from "../../../../../chunks/zod.js";
import { t as toWritableStores, c as createBitAttrs, r as removeUndefined, g as getOptionUpdater, F as Field, a as getDataFsError, b as getFormControl, s as superForm, d as toast, e as Form_field, C as Control, I as Input, f as Form_field_errors, h as Form_button, T as Toaster } from "../../../../../chunks/Toaster.js";
import "../../../../../chunks/index.js";
import { T as Trash2, S as Star } from "../../../../../chunks/trash-2.js";
import { w as withGet, m as makeElement, d as disabledAttr, e as executeCallbacks, a as addMeltEventListener, s as styleToString, k as kbd, c as cn } from "../../../../../chunks/index3.js";
function omit(obj, ...keys) {
  const result = {};
  for (const key of Object.keys(obj)) {
    if (!keys.includes(key)) {
      result[key] = obj[key];
    }
  }
  return result;
}
const overridable = (_store, onChange) => {
  const store = withGet(_store);
  const update = (updater, sideEffect) => {
    store.update((curr) => {
      const next = updater(curr);
      let res = next;
      if (onChange) {
        res = onChange({ curr, next });
      }
      sideEffect?.(res);
      return res;
    });
  };
  const set = (curr) => {
    update(() => curr);
  };
  return {
    ...store,
    update,
    set
  };
};
const defaults = {
  disabled: false,
  required: false,
  name: void 0,
  value: "on",
  defaultChecked: false
};
function createCheckbox(props) {
  const withDefaults = { ...defaults, ...props };
  const options = toWritableStores(omit(withDefaults, "checked", "defaultChecked"));
  const { disabled, name, required, value } = options;
  const checkedWritable = withDefaults.checked ?? writable(withDefaults.defaultChecked);
  const checked = overridable(checkedWritable, withDefaults?.onCheckedChange);
  const root = makeElement("checkbox", {
    stores: [checked, disabled, required],
    returned: ([$checked, $disabled, $required]) => {
      return {
        "data-disabled": disabledAttr($disabled),
        disabled: disabledAttr($disabled),
        "data-state": $checked === "indeterminate" ? "indeterminate" : $checked ? "checked" : "unchecked",
        type: "button",
        role: "checkbox",
        "aria-checked": $checked === "indeterminate" ? "mixed" : $checked,
        "aria-required": $required
      };
    },
    action: (node) => {
      const unsub = executeCallbacks(addMeltEventListener(node, "keydown", (e) => {
        if (e.key === kbd.ENTER)
          e.preventDefault();
      }), addMeltEventListener(node, "click", () => {
        if (disabled.get())
          return;
        checked.update((value2) => {
          if (value2 === "indeterminate")
            return true;
          return !value2;
        });
      }));
      return {
        destroy: unsub
      };
    }
  });
  const input = makeElement("checkbox-input", {
    stores: [checked, name, value, required, disabled],
    returned: ([$checked, $name, $value, $required, $disabled]) => {
      return {
        type: "checkbox",
        "aria-hidden": true,
        hidden: true,
        tabindex: -1,
        name: $name,
        value: $value,
        checked: $checked === "indeterminate" ? false : $checked,
        required: $required,
        disabled: disabledAttr($disabled),
        style: styleToString({
          position: "absolute",
          opacity: 0,
          "pointer-events": "none",
          margin: 0,
          transform: "translateX(-100%)"
        })
      };
    }
  });
  const isIndeterminate = derived(checked, ($checked) => $checked === "indeterminate");
  const isChecked = derived(checked, ($checked) => $checked === true);
  return {
    elements: {
      root,
      input
    },
    states: {
      checked
    },
    helpers: {
      isIndeterminate,
      isChecked
    },
    options
  };
}
function createLabel() {
  const root = makeElement("label", {
    action: (node) => {
      const mouseDown = addMeltEventListener(node, "mousedown", (e) => {
        if (!e.defaultPrevented && e.detail > 1) {
          e.preventDefault();
        }
      });
      return {
        destroy: mouseDown
      };
    }
  });
  return {
    elements: {
      root
    }
  };
}
function createDispatcher() {
  const dispatch = createEventDispatcher();
  return (e) => {
    const { originalEvent } = e.detail;
    const { cancelable } = e;
    const type = originalEvent.type;
    const shouldContinue = dispatch(type, { originalEvent, currentTarget: originalEvent.currentTarget }, { cancelable });
    if (!shouldContinue) {
      e.preventDefault();
    }
  };
}
function getCheckboxData() {
  const NAME = "checkbox";
  const PARTS = ["root", "input", "indicator"];
  return {
    NAME,
    PARTS
  };
}
function setCtx(props) {
  const { NAME, PARTS } = getCheckboxData();
  const getAttrs = createBitAttrs(NAME, PARTS);
  const checkbox = { ...createCheckbox(removeUndefined(props)), getAttrs };
  setContext(NAME, checkbox);
  return {
    ...checkbox,
    updateOption: getOptionUpdater(checkbox.options)
  };
}
function getCtx() {
  const { NAME } = getCheckboxData();
  return getContext(NAME);
}
const Checkbox$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let attrs;
  let builder;
  let $$restProps = compute_rest_props($$props, [
    "checked",
    "disabled",
    "name",
    "required",
    "value",
    "onCheckedChange",
    "asChild",
    "el"
  ]);
  let $root, $$unsubscribe_root;
  let { checked = false } = $$props;
  let { disabled = void 0 } = $$props;
  let { name = void 0 } = $$props;
  let { required = void 0 } = $$props;
  let { value = void 0 } = $$props;
  let { onCheckedChange = void 0 } = $$props;
  let { asChild = false } = $$props;
  let { el = void 0 } = $$props;
  const { elements: { root }, states: { checked: localChecked }, updateOption, getAttrs } = setCtx({
    defaultChecked: checked,
    disabled,
    name,
    required,
    value,
    onCheckedChange: ({ next }) => {
      if (checked !== next) {
        onCheckedChange?.(next);
        checked = next;
      }
      return next;
    }
  });
  $$unsubscribe_root = subscribe(root, (value2) => $root = value2);
  createDispatcher();
  if ($$props.checked === void 0 && $$bindings.checked && checked !== void 0)
    $$bindings.checked(checked);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0)
    $$bindings.disabled(disabled);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.required === void 0 && $$bindings.required && required !== void 0)
    $$bindings.required(required);
  if ($$props.value === void 0 && $$bindings.value && value !== void 0)
    $$bindings.value(value);
  if ($$props.onCheckedChange === void 0 && $$bindings.onCheckedChange && onCheckedChange !== void 0)
    $$bindings.onCheckedChange(onCheckedChange);
  if ($$props.asChild === void 0 && $$bindings.asChild && asChild !== void 0)
    $$bindings.asChild(asChild);
  if ($$props.el === void 0 && $$bindings.el && el !== void 0)
    $$bindings.el(el);
  attrs = {
    ...getAttrs("root"),
    disabled: disabled ? true : void 0
  };
  checked !== void 0 && localChecked.set(checked);
  {
    updateOption("disabled", disabled);
  }
  {
    updateOption("name", name);
  }
  {
    updateOption("required", required);
  }
  {
    updateOption("value", value);
  }
  builder = $root;
  {
    Object.assign(builder, attrs);
  }
  $$unsubscribe_root();
  return `${asChild ? `${slots.default ? slots.default({ builder }) : ``}` : `<button${spread([escape_object(builder), { type: "button" }, escape_object($$restProps)], {})}${add_attribute("this", el, 0)}>${slots.default ? slots.default({ builder }) : ``}</button>`}`;
});
function getStateAttr(state) {
  if (state === "indeterminate")
    return "indeterminate";
  if (state)
    return "checked";
  return "unchecked";
}
const Checkbox_indicator = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let attrs;
  let $$restProps = compute_rest_props($$props, ["asChild", "el"]);
  let $checked, $$unsubscribe_checked;
  let $isChecked, $$unsubscribe_isChecked;
  let $isIndeterminate, $$unsubscribe_isIndeterminate;
  let { asChild = false } = $$props;
  let { el = void 0 } = $$props;
  const { helpers: { isChecked, isIndeterminate }, states: { checked }, getAttrs } = getCtx();
  $$unsubscribe_isChecked = subscribe(isChecked, (value) => $isChecked = value);
  $$unsubscribe_isIndeterminate = subscribe(isIndeterminate, (value) => $isIndeterminate = value);
  $$unsubscribe_checked = subscribe(checked, (value) => $checked = value);
  if ($$props.asChild === void 0 && $$bindings.asChild && asChild !== void 0)
    $$bindings.asChild(asChild);
  if ($$props.el === void 0 && $$bindings.el && el !== void 0)
    $$bindings.el(el);
  attrs = {
    ...getAttrs("indicator"),
    "data-state": getStateAttr($checked)
  };
  $$unsubscribe_checked();
  $$unsubscribe_isChecked();
  $$unsubscribe_isIndeterminate();
  return `${asChild ? `${slots.default ? slots.default({
    attrs,
    isChecked: $isChecked,
    isIndeterminate: $isIndeterminate
  }) : ``}` : `<div${spread([escape_object($$restProps), escape_object(attrs)], {})}${add_attribute("this", el, 0)}>${slots.default ? slots.default({
    attrs,
    isChecked: $isChecked,
    isIndeterminate: $isIndeterminate
  }) : ``}</div>`}`;
});
function getLabelData() {
  const NAME = "label";
  const PARTS = ["root"];
  const getAttrs = createBitAttrs(NAME, PARTS);
  return {
    NAME,
    getAttrs
  };
}
const Label$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let builder;
  let $$restProps = compute_rest_props($$props, ["asChild", "el"]);
  let $root, $$unsubscribe_root;
  let { asChild = false } = $$props;
  let { el = void 0 } = $$props;
  const { elements: { root } } = createLabel();
  $$unsubscribe_root = subscribe(root, (value) => $root = value);
  createDispatcher();
  const { getAttrs } = getLabelData();
  const attrs = getAttrs("root");
  if ($$props.asChild === void 0 && $$bindings.asChild && asChild !== void 0)
    $$bindings.asChild(asChild);
  if ($$props.el === void 0 && $$bindings.el && el !== void 0)
    $$bindings.el(el);
  builder = $root;
  {
    Object.assign(builder, attrs);
  }
  $$unsubscribe_root();
  return `${asChild ? `${slots.default ? slots.default({ builder }) : ``}` : `<label${spread([escape_object(builder), escape_object($$restProps)], {})}${add_attribute("this", el, 0)}>${slots.default ? slots.default({ builder }) : ``}</label>`}`;
});
const userRating = writable(0);
const GenreTable = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { genres } = $$props;
  if ($$props.genres === void 0 && $$bindings.genres && genres !== void 0)
    $$bindings.genres(genres);
  return `<table class="mx-4 mb-2 w-full table-auto"><tbody>${each(genres, ({ description, id }) => {
    return `<tr><td class="text-start">${escape(description)}</td> <td class="w-24"><form action="?/deleteGenre" method="post"><input type="hidden" name="id"${add_attribute("value", id, 0)}> <button>${validate_component(Trash2, "Trash2").$$render($$result, { color: "crimson", size: 16 }, {}, {})}</button> </form></td> </tr>`;
  })}</tbody></table>`;
});
const Fieldset = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let fieldsetAttrs;
  let $$restProps = compute_rest_props($$props, ["form", "name", "asChild", "el"]);
  let { form } = $$props;
  let { name } = $$props;
  let { asChild = false } = $$props;
  let { el = void 0 } = $$props;
  if ($$props.form === void 0 && $$bindings.form && form !== void 0)
    $$bindings.form(form);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.asChild === void 0 && $$bindings.asChild && asChild !== void 0)
    $$bindings.asChild(asChild);
  if ($$props.el === void 0 && $$bindings.el && el !== void 0)
    $$bindings.el(el);
  fieldsetAttrs = { "data-fs-fieldset": "", ...$$restProps };
  return ` ${validate_component(Field, "Field").$$render($$result, { form, name }, {}, {
    default: ({ value, errors, tainted, constraints }) => {
      return `${asChild ? `${slots.default ? slots.default({
        fieldsetAttrs,
        value,
        errors,
        tainted,
        constraints
      }) : ``}` : `<fieldset${spread(
        [
          escape_object(fieldsetAttrs),
          {
            "data-fs-error": escape_attribute_value(getDataFsError(errors))
          }
        ],
        {}
      )}${add_attribute("this", el, 0)}>${slots.default ? slots.default({
        fieldsetAttrs,
        value,
        errors,
        tainted,
        constraints
      }) : ``}</fieldset>`}`;
    }
  })}`;
});
const Label = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["class"]);
  let { class: className = void 0 } = $$props;
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  return `${validate_component(Label$1, "LabelPrimitive.Root").$$render(
    $$result,
    Object.assign(
      {},
      {
        class: cn("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", className)
      },
      $$restProps
    ),
    {},
    {
      default: () => {
        return `${slots.default ? slots.default({}) : ``}`;
      }
    }
  )}`;
});
const Form_label = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["class"]);
  let $labelAttrs, $$unsubscribe_labelAttrs;
  let { class: className = void 0 } = $$props;
  const { labelAttrs } = getFormControl();
  $$unsubscribe_labelAttrs = subscribe(labelAttrs, (value) => $labelAttrs = value);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  $$unsubscribe_labelAttrs();
  return `${validate_component(Label, "Label").$$render(
    $$result,
    Object.assign(
      {},
      $labelAttrs,
      {
        class: cn("data-[fs-error]:text-destructive", className)
      },
      $$restProps
    ),
    {},
    {
      default: () => {
        return `${slots.default ? slots.default({ labelAttrs }) : ``}`;
      }
    }
  )}`;
});
const Form_fieldset = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { form } = $$props;
  let { name } = $$props;
  let { class: className = void 0 } = $$props;
  if ($$props.form === void 0 && $$bindings.form && form !== void 0)
    $$bindings.form(form);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  return `${validate_component(Fieldset, "FormPrimitive.Fieldset").$$render(
    $$result,
    {
      form,
      name,
      class: cn("space-y-2", className)
    },
    {},
    {
      default: ({ constraints, errors, tainted, value }) => {
        return `${slots.default ? slots.default({ constraints, errors, tainted, value }) : ``}`;
      }
    }
  )}`;
});
const Genres = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $formData, $$unsubscribe_formData;
  let { data } = $$props;
  let { genres } = $$props;
  const form = superForm(data, {
    validators: zodClient(genreSchema),
    onUpdated: ({ form: f }) => {
      if (f.valid) {
        toast.success(`Created ${JSON.stringify(f.data.description, null, 2)}`);
      }
    }
  });
  const { form: formData } = form;
  $$unsubscribe_formData = subscribe(formData, (value) => $formData = value);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  if ($$props.genres === void 0 && $$bindings.genres && genres !== void 0)
    $$bindings.genres(genres);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `${validate_component(Card, "Card").$$render($$result, { header: "genres" }, {}, {
      default: () => {
        return `<form action="?/insertGenre" class="my-4" method="post">${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "description", class: "mx-4" }, {}, {
          default: () => {
            return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
              default: ({ attrs }) => {
                return `${validate_component(Input, "Input").$$render(
                  $$result,
                  Object.assign(
                    {},
                    attrs,
                    { placeholder: "Add a Genre" },
                    { autocomplete: "off" },
                    { spellcheck: "false" },
                    {
                      class: "rounded-md p-2 ring-1 ring-slate-400"
                    },
                    { value: $formData.description }
                  ),
                  {
                    value: ($$value) => {
                      $formData.description = $$value;
                      $$settled = false;
                    }
                  },
                  {}
                )}`;
              }
            })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
          }
        })} <div class="text-center">${validate_component(Form_button, "Form.Button").$$render(
          $$result,
          {
            class: "bg-blue-500 font-bold uppercase text-white"
          },
          {},
          {
            default: () => {
              return `Submit`;
            }
          }
        )}</div></form> <hr class="mx-2 border-white"> <div class="mt-2">${validate_component(GenreTable, "GenreTable").$$render($$result, { genres }, {}, {})}</div>`;
      }
    })} ${validate_component(Toaster, "Toaster").$$render($$result, { richColors: true }, {}, {})}`;
  } while (!$$settled);
  $$unsubscribe_formData();
  return $$rendered;
});
const Rating = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $userRating, $$unsubscribe_userRating;
  $$unsubscribe_userRating = subscribe(userRating, (value) => $userRating = value);
  $$unsubscribe_userRating();
  return `${each([1, 2, 3, 4, 5], (star) => {
    return `<button type="button">${validate_component(Star, "Star").$$render(
      $$result,
      {
        size: 32,
        strokeWidth: 0,
        fill: star <= $userRating ? "gold" : ""
      },
      {},
      {}
    )} </button>`;
  })} <input hidden type="number" name="rating"${add_attribute("value", $userRating, 0)}>`;
});
const Textarea = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["class", "value"]);
  let { class: className = void 0 } = $$props;
  let { value = void 0 } = $$props;
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  if ($$props.value === void 0 && $$bindings.value && value !== void 0)
    $$bindings.value(value);
  return `<textarea${spread(
    [
      {
        class: escape_attribute_value(cn("border-input placeholder:text-muted-foreground focus-visible:ring-ring flex min-h-[60px] w-full rounded-md border bg-transparent px-3 py-2 text-sm shadow-sm focus-visible:ring-1 disabled:cursor-not-allowed disabled:opacity-50", className))
      },
      escape_object($$restProps)
    ],
    {}
  )}>${escape(value || "")}</textarea>`;
});
const Check = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["size", "role", "color", "ariaLabel"]);
  const ctx = getContext("iconCtx") ?? {};
  let { size = ctx.size || "24" } = $$props;
  let { role = ctx.role || "img" } = $$props;
  let { color = ctx.color || "currentColor" } = $$props;
  let { ariaLabel = "check" } = $$props;
  if ($$props.size === void 0 && $$bindings.size && size !== void 0)
    $$bindings.size(size);
  if ($$props.role === void 0 && $$bindings.role && role !== void 0)
    $$bindings.role(role);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0)
    $$bindings.color(color);
  if ($$props.ariaLabel === void 0 && $$bindings.ariaLabel && ariaLabel !== void 0)
    $$bindings.ariaLabel(ariaLabel);
  return `<svg${spread(
    [
      { width: escape_attribute_value(size) },
      { height: escape_attribute_value(size) },
      escape_object($$restProps),
      { role: escape_attribute_value(role) },
      {
        "aria-label": escape_attribute_value(ariaLabel)
      },
      { viewBox: "0 0 15 15" },
      { fill: escape_attribute_value(color) },
      { xmlns: "http://www.w3.org/2000/svg" }
    ],
    {}
  )}><path fill-rule="evenodd" clip-rule="evenodd" d="M11.4669 3.72684C11.7558 3.91574 11.8369 4.30308 11.648 4.59198L7.39799 11.092C7.29783 11.2452 7.13556 11.3467 6.95402 11.3699C6.77247 11.3931 6.58989 11.3355 6.45446 11.2124L3.70446 8.71241C3.44905 8.48022 3.43023 8.08494 3.66242 7.82953C3.89461 7.57412 4.28989 7.55529 4.5453 7.78749L6.75292 9.79441L10.6018 3.90792C10.7907 3.61902 11.178 3.53795 11.4669 3.72684Z"></path></svg> `;
});
const Minus = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["size", "role", "color", "ariaLabel"]);
  const ctx = getContext("iconCtx") ?? {};
  let { size = ctx.size || "24" } = $$props;
  let { role = ctx.role || "img" } = $$props;
  let { color = ctx.color || "currentColor" } = $$props;
  let { ariaLabel = "minus" } = $$props;
  if ($$props.size === void 0 && $$bindings.size && size !== void 0)
    $$bindings.size(size);
  if ($$props.role === void 0 && $$bindings.role && role !== void 0)
    $$bindings.role(role);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0)
    $$bindings.color(color);
  if ($$props.ariaLabel === void 0 && $$bindings.ariaLabel && ariaLabel !== void 0)
    $$bindings.ariaLabel(ariaLabel);
  return `<svg${spread(
    [
      { width: escape_attribute_value(size) },
      { height: escape_attribute_value(size) },
      escape_object($$restProps),
      { role: escape_attribute_value(role) },
      {
        "aria-label": escape_attribute_value(ariaLabel)
      },
      { viewBox: "0 0 15 15" },
      { fill: escape_attribute_value(color) },
      { xmlns: "http://www.w3.org/2000/svg" }
    ],
    {}
  )}><path fill-rule="evenodd" clip-rule="evenodd" d="M2.25 7.5C2.25 7.22386 2.47386 7 2.75 7H12.25C12.5261 7 12.75 7.22386 12.75 7.5C12.75 7.77614 12.5261 8 12.25 8H2.75C2.47386 8 2.25 7.77614 2.25 7.5Z"></path></svg> `;
});
const Checkbox = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["class", "checked"]);
  let { class: className = void 0 } = $$props;
  let { checked = false } = $$props;
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  if ($$props.checked === void 0 && $$bindings.checked && checked !== void 0)
    $$bindings.checked(checked);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `${validate_component(Checkbox$1, "CheckboxPrimitive.Root").$$render(
      $$result,
      Object.assign(
        {},
        {
          class: cn("peer box-content h-4 w-4 shrink-0 rounded-sm border border-primary shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[disabled=true]:cursor-not-allowed data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground data-[disabled=true]:opacity-50", className)
        },
        $$restProps,
        { checked }
      ),
      {
        checked: ($$value) => {
          checked = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Checkbox_indicator, "CheckboxPrimitive.Indicator").$$render(
            $$result,
            {
              class: cn("flex h-4 w-4 items-center justify-center text-current")
            },
            {},
            {
              default: ({ isChecked, isIndeterminate }) => {
                return `${isIndeterminate ? `${validate_component(Minus, "Minus").$$render($$result, { class: "h-3.5 w-3.5" }, {}, {})}` : `${validate_component(Check, "Check").$$render(
                  $$result,
                  {
                    class: cn("h-3.5 w-3.5", !isChecked && "text-transparent")
                  },
                  {},
                  {}
                )}`}`;
              }
            }
          )}`;
        }
      }
    )}`;
  } while (!$$settled);
  return $$rendered;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $formData, $$unsubscribe_formData;
  let $userRating, $$unsubscribe_userRating;
  $$unsubscribe_userRating = subscribe(userRating, (value) => $userRating = value);
  let { data } = $$props;
  const form = superForm(data.form, {
    validators: zodClient(bookSchema),
    dataType: "json"
  });
  const { form: formData, enhance } = form;
  $$unsubscribe_formData = subscribe(formData, (value) => $formData = value);
  userRating.set($formData.rating);
  const addGenre = (id, description) => {
    set_store_value(formData, $formData.genres = [...$formData.genres, { id, description }], $formData);
  };
  const removeGenre = (id) => {
    set_store_value(formData, $formData.genres = $formData.genres.filter((e) => e.id != id), $formData);
  };
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    set_store_value(formData, $formData.rating = $userRating, $formData);
    $$rendered = `<div class="container mx-auto mt-2 lg:flex lg:gap-2"><div class="lg:w-9/12">${validate_component(Card, "Card").$$render(
      $$result,
      {
        header: $formData.id ? "Update Book" : "Create Book"
      },
      {},
      {
        default: () => {
          return `<form action="?/modify" method="post"><div class="mx-2">${validate_component(Form_field, "Form.Field").$$render(
            $$result,
            {
              form,
              name: "title",
              class: "mx-4 mb-4 mt-4"
            },
            {},
            {
              default: () => {
                return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                  default: ({ attrs }) => {
                    return `${validate_component(Input, "Input").$$render(
                      $$result,
                      Object.assign(
                        {},
                        attrs,
                        {
                          class: "rounded-md p-2 ring-1 ring-slate-400"
                        },
                        { placeholder: "Title" },
                        { autocomplete: "off" },
                        { spellcheck: "false" },
                        { value: $formData.title }
                      ),
                      {
                        value: ($$value) => {
                          $formData.title = $$value;
                          $$settled = false;
                        }
                      },
                      {}
                    )}`;
                  }
                })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
              }
            }
          )} ${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "author", class: "m-4" }, {}, {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      {
                        class: "rounded-md p-2 ring-1 ring-slate-400"
                      },
                      { placeholder: "Author" },
                      { autocomplete: "off" },
                      { spellcheck: "false" },
                      { value: $formData.author }
                    ),
                    {
                      value: ($$value) => {
                        $formData.author = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          })} ${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "review", class: "m-4" }, {}, {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Textarea, "Textarea").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      {
                        class: "rounded-md p-2 ring-1 ring-slate-400"
                      },
                      { placeholder: "Review" },
                      { autocomplete: "off" },
                      { spellcheck: "false" },
                      { value: $formData.review }
                    ),
                    {
                      value: ($$value) => {
                        $formData.review = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          })}  <div class="m-4 mt-6 rounded-md border-2 border-purple-500 px-2 py-1 text-center"><div class="mb-2 font-bold underline" data-svelte-h="svelte-dt6bmo">Genres</div> ${validate_component(Form_fieldset, "Form.Fieldset").$$render($$result, { form, name: "genres" }, {}, {
            default: () => {
              return `<div class="mb-2 grid grid-cols-2 gap-2 lg:grid-cols-4">${each(data.genres, (genre) => {
                let checked = $formData.genres.some((e) => e.id === genre.id);
                return ` <div class="flex items-center">${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                  default: ({ attrs }) => {
                    return `${validate_component(Checkbox, "Checkbox").$$render(
                      $$result,
                      Object.assign({}, attrs, { checked }, {
                        onCheckedChange: (e) => {
                          if (e)
                            addGenre(genre.id, genre.description);
                          else
                            removeGenre(genre.id);
                        }
                      }),
                      {},
                      {}
                    )} ${validate_component(Form_label, "Form.Label").$$render($$result, { class: "ml-2" }, {}, {
                      default: () => {
                        return `${escape(genre.description)}`;
                      }
                    })} <input hidden type="checkbox"${add_attribute("name", attrs.name, 0)}${add_attribute("value", genre.id, 0)} ${checked ? "checked" : ""}> `;
                  }
                })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})} </div>`;
              })}</div>`;
            }
          })}</div>  <div class="m-4 mt-6 flex items-center justify-center gap-12"><div>${validate_component(Rating, "Rating").$$render($$result, {}, {}, {})}</div> <div class="flex justify-center">${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "isFiction" }, {}, {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Checkbox, "Checkbox").$$render(
                    $$result,
                    Object.assign({}, attrs, { checked: $formData.isFiction }),
                    {
                      checked: ($$value) => {
                        $formData.isFiction = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )} ${validate_component(Form_label, "Form.Label").$$render($$result, {}, {}, {
                    default: () => {
                      return `Is Fiction?`;
                    }
                  })} <input${add_attribute("name", attrs.name, 0)}${add_attribute("value", $formData.isFiction, 0)} hidden>`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          })}</div></div>  <div class="m-4 lg:flex lg:content-center lg:justify-evenly">${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "pages" }, {}, {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { type: "number" },
                      { placeholder: "Pages" },
                      {
                        class: "rounded-md p-2 ring-1 ring-slate-400"
                      },
                      { autocomplete: "off" },
                      { value: $formData.pages }
                    ),
                    {
                      value: ($$value) => {
                        $formData.pages = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          })} ${validate_component(Form_field, "Form.Field").$$render($$result, { form, name: "publishDate" }, {}, {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { type: "number" },
                      { placeholder: "Publish Date" },
                      {
                        class: "rounded-md p-2 ring-1 ring-slate-400"
                      },
                      { autocomplete: "off" },
                      { value: $formData.publishDate }
                    ),
                    {
                      value: ($$value) => {
                        $formData.publishDate = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          })}</div>  <div class="text-center">${validate_component(Form_button, "Form.Button").$$render(
            $$result,
            {
              class: "m-4 w-1/2 bg-blue-500 font-bold uppercase text-white"
            },
            {},
            {
              default: () => {
                return `${escape($formData.id ? "Update" : "Create")}`;
              }
            }
          )}</div></div></form>`;
        }
      }
    )}</div> <div class="mt-2 w-full lg:mt-0 lg:w-3/12">${validate_component(Genres, "Genres").$$render(
      $$result,
      {
        data: data.genreForm,
        genres: data.genres
      },
      {},
      {}
    )}</div></div>`;
  } while (!$$settled);
  $$unsubscribe_formData();
  $$unsubscribe_userRating();
  return $$rendered;
});
export {
  Page as default
};
