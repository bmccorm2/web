import { e as error } from "../../../chunks/index.js";
import { c as client, G as GET_BOOKS, D as DELETE_BGA, a as DELETE_BOOK } from "../../../chunks/queries.js";
import { s as serializeBooks } from "../../../chunks/utilities.js";
const load = async () => {
  try {
    const res = await client.execute(GET_BOOKS);
    const rows = res.rows;
    const books = serializeBooks(rows);
    return { books };
  } catch (e) {
    error(505, e.message);
  }
};
const actions = {
  deleteBook: async ({ request }) => {
    const formData = await request.formData();
    const id = parseInt(formData.get("id"));
    const transaction = await client.transaction("write");
    await transaction.execute({
      sql: DELETE_BGA,
      args: { id }
    });
    await transaction.execute({
      sql: DELETE_BOOK,
      args: { id }
    });
    await transaction.commit();
    return { success: "true" };
  }
};
export {
  actions,
  load
};
