import { c as create_ssr_component } from "../../chunks/ssr.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<!-- HEAD_svelte-14vj72_START -->${$$result.title = `<title>Home</title>`, ""}<meta name="description" content="Home Page"><!-- HEAD_svelte-14vj72_END -->`, ""}`;
});
export {
  Page as default
};
