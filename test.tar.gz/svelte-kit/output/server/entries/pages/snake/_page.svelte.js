import { c as create_ssr_component, d as escape, e as each, A as null_to_empty } from "../../../chunks/ssr.js";
const css = {
  code: ".row.svelte-19xbckq{display:flex}.square.svelte-19xbckq{height:26px;width:26px;border:solid 1px gray}.snake.svelte-19xbckq{background-color:blue}.food.svelte-19xbckq{background-color:red}.center.svelte-19xbckq{display:grid;justify-content:center;align-items:center;margin-top:1rem}.lost.svelte-19xbckq{display:grid;justify-content:center;align-items:center;margin-top:1rem;color:red}.right.svelte-19xbckq{text-align:right}",
  map: null
};
const GRID_SIZE = 20;
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let snakePosition = [[12, 8]];
  let highScore = 1;
  let grid = [...Array(GRID_SIZE)].map(() => [...Array(GRID_SIZE)].map(() => "empty"));
  const getRandomInt = (max) => {
    return Math.floor(Math.random() * Math.floor(max));
  };
  const generateRandomFood = () => {
    grid[getRandomInt(GRID_SIZE)][getRandomInt(GRID_SIZE)] = "food";
    grid[getRandomInt(GRID_SIZE)][getRandomInt(GRID_SIZE)] = "food";
  };
  generateRandomFood();
  $$result.css.add(css);
  {
    {
      for (let i = 0; i < grid.length; i++) {
        for (let j = 0; j < grid[i].length; j++) {
          if (grid[i][j] === "snake") {
            grid[i][j] = "empty";
          }
        }
      }
      snakePosition.forEach(([x, y]) => {
        grid[x][y] = "snake";
      });
      if (snakePosition.length > highScore)
        highScore = snakePosition.length;
    }
  }
  return ` ${$$result.head += `<!-- HEAD_svelte-gfb4jv_START -->${$$result.title = `<title>Snake</title>`, ""}<meta name="description" content="retro snake game"><!-- HEAD_svelte-gfb4jv_END -->`, ""} <div class="container mx-auto"><div class="center svelte-19xbckq"><div><h3 style="float: left;">Snake Length: ${escape(snakePosition.length)}</h3> <h3 style="float: right;">High Score: ${escape(highScore)}</h3></div> ${each(grid, (row) => {
    return `<div class="row svelte-19xbckq">${each(row, (cell) => {
      return `<div class="${escape(null_to_empty(`square ${cell}`), true) + " svelte-19xbckq"}"></div>`;
    })} </div>`;
  })} ${``}</div> </div>`;
});
export {
  Page as default
};
