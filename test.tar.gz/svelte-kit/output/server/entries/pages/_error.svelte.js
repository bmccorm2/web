import { c as create_ssr_component, a as subscribe, d as escape } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
/* empty css               */
const Error = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe_page();
  return `<div class="container mx-auto"><h1 class="text-4xl mt-4">${escape($page.status)}: ${escape($page.error?.message)}</h1></div>`;
});
export {
  Error as default
};
