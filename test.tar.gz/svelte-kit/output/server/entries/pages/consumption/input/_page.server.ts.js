import { c as client, k as INSERT_CONSUMPTION } from "../../../../chunks/queries.js";
import { a as zod, i as inputSchema } from "../../../../chunks/zod.js";
import { f as fail, e as error } from "../../../../chunks/index.js";
import { s as superValidate } from "../../../../chunks/superValidate.js";
const load = async () => {
  return {
    form: await superValidate(zod(inputSchema))
  };
};
const actions = {
  create: async (event) => {
    const form = await superValidate(event, zod(inputSchema));
    if (!form.valid)
      return fail(400, { form });
    const { price, gallons, miles, notes } = form.data;
    const res = await client.execute({
      sql: INSERT_CONSUMPTION,
      args: {
        carId: 4,
        price,
        gallons,
        miles,
        notes
      }
    });
    if (res.rowsAffected != 1)
      error(505, "Error creating record");
    return { form };
  }
};
export {
  actions,
  load
};
