import { c as create_ssr_component, v as validate_component, h as compute_rest_props, a as subscribe, i as spread, j as escape_object, b as add_attribute, d as escape } from "../../../../chunks/ssr.js";
import { t as toWritableStores, c as createBitAttrs, r as removeUndefined, g as getOptionUpdater, T as Toaster, s as superForm, d as toast, e as Form_field, C as Control, I as Input, f as Form_field_errors, h as Form_button } from "../../../../chunks/Toaster.js";
import { z as zodClient, i as inputSchema } from "../../../../chunks/zod.js";
import "../../../../chunks/index.js";
import { C as Card } from "../../../../chunks/Card.js";
import { m as makeElement, c as cn } from "../../../../chunks/index3.js";
import { d as derived, w as writable } from "../../../../chunks/index2.js";
import { I as Icon } from "../../../../chunks/Icon.js";
const Car_front = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8"
      }
    ],
    ["path", { "d": "M7 14h.01" }],
    ["path", { "d": "M17 14h.01" }],
    [
      "rect",
      {
        "width": "18",
        "height": "8",
        "x": "3",
        "y": "10",
        "rx": "2"
      }
    ],
    ["path", { "d": "M5 18v2" }],
    ["path", { "d": "M19 18v2" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "car-front" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const CarFront = Car_front;
const Dollar_sign = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "line",
      {
        "x1": "12",
        "x2": "12",
        "y1": "2",
        "y2": "22"
      }
    ],
    [
      "path",
      {
        "d": "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "dollar-sign" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const DollarSign = Dollar_sign;
const Fuel = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "line",
      {
        "x1": "3",
        "x2": "15",
        "y1": "22",
        "y2": "22"
      }
    ],
    [
      "line",
      {
        "x1": "4",
        "x2": "14",
        "y1": "9",
        "y2": "9"
      }
    ],
    [
      "path",
      {
        "d": "M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18"
      }
    ],
    [
      "path",
      {
        "d": "M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "fuel" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Fuel$1 = Fuel;
const Sticky_note = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    [
      "path",
      {
        "d": "M16 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8Z"
      }
    ],
    ["path", { "d": "M15 3v4a2 2 0 0 0 2 2h4" }]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "sticky-note" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const StickyNote = Sticky_note;
const defaults = {
  orientation: "horizontal",
  decorative: false
};
const createSeparator = (props) => {
  const withDefaults = { ...defaults, ...props };
  const options = toWritableStores(withDefaults);
  const { orientation, decorative } = options;
  const root = makeElement("separator", {
    stores: [orientation, decorative],
    returned: ([$orientation, $decorative]) => {
      const ariaOrientation = $orientation === "vertical" ? $orientation : void 0;
      return {
        role: $decorative ? "none" : "separator",
        "aria-orientation": ariaOrientation,
        "aria-hidden": $decorative,
        "data-orientation": $orientation
      };
    }
  });
  return {
    elements: {
      root
    },
    options
  };
};
function getSeparatorData() {
  const NAME = "separator";
  const PARTS = ["root"];
  return {
    NAME,
    PARTS
  };
}
function setCtx(props) {
  const { NAME, PARTS } = getSeparatorData();
  const getAttrs = createBitAttrs(NAME, PARTS);
  const separator = { ...createSeparator(removeUndefined(props)), getAttrs };
  return {
    ...separator,
    updateOption: getOptionUpdater(separator.options)
  };
}
const Separator$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let builder;
  let $$restProps = compute_rest_props($$props, ["orientation", "decorative", "asChild", "el"]);
  let $root, $$unsubscribe_root;
  let { orientation = "horizontal" } = $$props;
  let { decorative = true } = $$props;
  let { asChild = false } = $$props;
  let { el = void 0 } = $$props;
  const { elements: { root }, updateOption, getAttrs } = setCtx({ orientation, decorative });
  $$unsubscribe_root = subscribe(root, (value) => $root = value);
  const attrs = getAttrs("root");
  if ($$props.orientation === void 0 && $$bindings.orientation && orientation !== void 0)
    $$bindings.orientation(orientation);
  if ($$props.decorative === void 0 && $$bindings.decorative && decorative !== void 0)
    $$bindings.decorative(decorative);
  if ($$props.asChild === void 0 && $$bindings.asChild && asChild !== void 0)
    $$bindings.asChild(asChild);
  if ($$props.el === void 0 && $$bindings.el && el !== void 0)
    $$bindings.el(el);
  {
    updateOption("orientation", orientation);
  }
  {
    updateOption("decorative", decorative);
  }
  builder = $root;
  {
    Object.assign(builder, attrs);
  }
  $$unsubscribe_root();
  return `${asChild ? `${slots.default ? slots.default({ builder }) : ``}` : `<div${spread([escape_object(builder), escape_object($$restProps)], {})}${add_attribute("this", el, 0)}></div>`}`;
});
const InputIcon = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<span class="flex content-center rounded-l-md border border-white bg-gray-500 px-4 py-1">${slots.default ? slots.default({}) : ``}</span>`;
});
const Separator = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["class", "orientation", "decorative"]);
  let { class: className = void 0 } = $$props;
  let { orientation = "horizontal" } = $$props;
  let { decorative = void 0 } = $$props;
  if ($$props.class === void 0 && $$bindings.class && className !== void 0)
    $$bindings.class(className);
  if ($$props.orientation === void 0 && $$bindings.orientation && orientation !== void 0)
    $$bindings.orientation(orientation);
  if ($$props.decorative === void 0 && $$bindings.decorative && decorative !== void 0)
    $$bindings.decorative(decorative);
  return `${validate_component(Separator$1, "SeparatorPrimitive.Root").$$render(
    $$result,
    Object.assign(
      {},
      {
        class: cn(
          "shrink-0 bg-border",
          orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
          className
        )
      },
      { orientation },
      { decorative },
      $$restProps
    ),
    {},
    {}
  )}`;
});
let timeoutAction;
let timeoutEnable;
function withoutTransition(action) {
  if (typeof document === "undefined")
    return;
  clearTimeout(timeoutAction);
  clearTimeout(timeoutEnable);
  const style = document.createElement("style");
  const css = document.createTextNode(`* {
     -webkit-transition: none !important;
     -moz-transition: none !important;
     -o-transition: none !important;
     -ms-transition: none !important;
     transition: none !important;
  }`);
  style.appendChild(css);
  const disable = () => document.head.appendChild(style);
  const enable = () => document.head.removeChild(style);
  if (typeof window.getComputedStyle !== "undefined") {
    disable();
    action();
    window.getComputedStyle(style).opacity;
    enable();
    return;
  }
  if (typeof window.requestAnimationFrame !== "undefined") {
    disable();
    action();
    window.requestAnimationFrame(enable);
    return;
  }
  disable();
  timeoutAction = window.setTimeout(() => {
    action();
    timeoutEnable = window.setTimeout(enable, 120);
  }, 120);
}
const noopStorage = {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  getItem: (_key) => null,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  setItem: (_key, _value) => {
  }
};
const isBrowser = typeof document !== "undefined";
const modes = ["dark", "light", "system"];
const localStorageKey = "mode-watcher-mode";
const userPrefersMode = createUserPrefersMode();
const systemPrefersMode = createSystemMode();
const themeColors = writable(void 0);
const derivedMode = createDerivedMode();
function createUserPrefersMode() {
  const defaultValue = "system";
  const storage = isBrowser ? localStorage : noopStorage;
  const initialValue = storage.getItem(localStorageKey);
  let value = isValidMode(initialValue) ? initialValue : defaultValue;
  const { subscribe: subscribe2, set: _set } = writable(value, () => {
    if (!isBrowser)
      return;
    const handler = (e) => {
      if (e.key !== localStorageKey)
        return;
      const newValue = e.newValue;
      if (isValidMode(newValue)) {
        _set(value = newValue);
      } else {
        _set(value = defaultValue);
      }
    };
    addEventListener("storage", handler);
    return () => removeEventListener("storage", handler);
  });
  function set(v) {
    _set(value = v);
    storage.setItem(localStorageKey, value);
  }
  return {
    subscribe: subscribe2,
    set
  };
}
function createSystemMode() {
  const defaultValue = void 0;
  let track = true;
  const { subscribe: subscribe2, set } = writable(defaultValue, () => {
    if (!isBrowser)
      return;
    const handler = (e) => {
      if (!track)
        return;
      set(e.matches ? "light" : "dark");
    };
    const mediaQueryState = window.matchMedia("(prefers-color-scheme: light)");
    mediaQueryState.addEventListener("change", handler);
    return () => mediaQueryState.removeEventListener("change", handler);
  });
  function query() {
    if (!isBrowser)
      return;
    const mediaQueryState = window.matchMedia("(prefers-color-scheme: light)");
    set(mediaQueryState.matches ? "light" : "dark");
  }
  function tracking(active) {
    track = active;
  }
  return {
    subscribe: subscribe2,
    query,
    tracking
  };
}
function createDerivedMode() {
  const { subscribe: subscribe2 } = derived([userPrefersMode, systemPrefersMode, themeColors], ([$userPrefersMode, $systemPrefersMode, $themeColors]) => {
    if (!isBrowser)
      return void 0;
    const derivedMode2 = $userPrefersMode === "system" ? $systemPrefersMode : $userPrefersMode;
    withoutTransition(() => {
      const htmlEl = document.documentElement;
      const themeColorEl = document.querySelector('meta[name="theme-color"]');
      if (derivedMode2 === "light") {
        htmlEl.classList.remove("dark");
        htmlEl.style.colorScheme = "light";
        if (themeColorEl && $themeColors) {
          themeColorEl.setAttribute("content", $themeColors.light);
        }
      } else {
        htmlEl.classList.add("dark");
        htmlEl.style.colorScheme = "dark";
        if (themeColorEl && $themeColors) {
          themeColorEl.setAttribute("content", $themeColors.dark);
        }
      }
    });
    return derivedMode2;
  });
  return {
    subscribe: subscribe2
  };
}
function isValidMode(value) {
  if (typeof value !== "string")
    return false;
  return modes.includes(value);
}
const Sonner_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, []);
  let $mode, $$unsubscribe_mode;
  $$unsubscribe_mode = subscribe(derivedMode, (value) => $mode = value);
  $$unsubscribe_mode();
  return `${validate_component(Toaster, "Sonner").$$render(
    $$result,
    Object.assign(
      {},
      { theme: $mode },
      { class: "toaster group" },
      {
        toastOptions: {
          classes: {
            toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
            description: "group-[.toast]:text-muted-foreground",
            actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
            cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
          }
        }
      },
      $$restProps
    ),
    {},
    {}
  )}`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let mpg;
  let ppg;
  let $formData, $$unsubscribe_formData;
  let { data } = $$props;
  let isSuccess = false;
  const form = superForm(data.form, {
    validators: zodClient(inputSchema),
    onUpdated: ({ form: f }) => {
      if (f.valid) {
        toast.success("Successfully created record");
        isSuccess = true;
      }
    }
  });
  const { form: formData, enhance } = form;
  $$unsubscribe_formData = subscribe(formData, (value) => $formData = value);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    mpg = $formData.miles && $formData.gallons ? ($formData.miles / $formData.gallons).toFixed(2) : "";
    ppg = $formData.price && $formData.gallons ? ($formData.price / $formData.gallons).toFixed(2) : "";
    $$rendered = `${$$result.head += `<!-- HEAD_svelte-19mseiu_START -->${$$result.title = `<title>Input</title>`, ""}<meta name="description" content="Input new consumption records"><!-- HEAD_svelte-19mseiu_END -->`, ""} <div class="container mx-auto mt-2">${validate_component(Card, "Card").$$render($$result, { header: "input", isSuccess }, {}, {
      default: () => {
        return `<form action="?/create" method="post"> <div class="mx-6 mt-4 flex items-center">${validate_component(InputIcon, "InputIcon").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(DollarSign, "DollarSign").$$render($$result, {}, {}, {})}`;
          }
        })} ${validate_component(Form_field, "Form.Field").$$render(
          $$result,
          {
            form,
            name: "price",
            class: "flex grow items-center"
          },
          {},
          {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { type: "number" },
                      { placeholder: "Price" },
                      { inputmode: "decimal" },
                      { step: ".01" },
                      {
                        class: "rounded-r-md border-2 border-slate-500 px-3 py-1 text-slate-200"
                      },
                      { value: $formData.price }
                    ),
                    {
                      value: ($$value) => {
                        $formData.price = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          }
        )}</div>  <div class="mx-6 mt-1 flex items-center">${validate_component(InputIcon, "InputIcon").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(Fuel$1, "Fuel").$$render($$result, {}, {}, {})}`;
          }
        })} ${validate_component(Form_field, "Form.Field").$$render(
          $$result,
          {
            form,
            name: "gallons",
            class: "flex grow items-center"
          },
          {},
          {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { type: "number" },
                      { placeholder: "Gallons" },
                      { inputmode: "decimal" },
                      { step: ".01" },
                      {
                        class: "rounded-r-md border-2 border-slate-500 px-3 py-1 text-slate-200"
                      },
                      { value: $formData.gallons }
                    ),
                    {
                      value: ($$value) => {
                        $formData.gallons = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          }
        )}</div>  <div class="mx-6 mt-1 flex items-center">${validate_component(InputIcon, "InputIcon").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(CarFront, "CarFront").$$render($$result, {}, {}, {})}`;
          }
        })} ${validate_component(Form_field, "Form.Field").$$render(
          $$result,
          {
            form,
            name: "miles",
            class: "flex grow items-center"
          },
          {},
          {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { type: "number" },
                      { placeholder: "Miles" },
                      { inputmode: "decimal" },
                      { step: ".01" },
                      {
                        class: "rounded-r-md border-2 border-slate-500 px-3 py-1 text-slate-200"
                      },
                      { value: $formData.miles }
                    ),
                    {
                      value: ($$value) => {
                        $formData.miles = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          }
        )}</div>  <div class="mx-6 mb-4 mt-1 flex items-center">${validate_component(InputIcon, "InputIcon").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(StickyNote, "StickyNote").$$render($$result, {}, {}, {})}`;
          }
        })} ${validate_component(Form_field, "Form.Field").$$render(
          $$result,
          {
            form,
            name: "notes",
            class: "flex grow items-center"
          },
          {},
          {
            default: () => {
              return `${validate_component(Control, "Form.Control").$$render($$result, {}, {}, {
                default: ({ attrs }) => {
                  return `${validate_component(Input, "Input").$$render(
                    $$result,
                    Object.assign(
                      {},
                      attrs,
                      { placeholder: "Notes" },
                      {
                        class: "rounded-r-md border-2 border-slate-500 px-3 py-1 text-slate-200"
                      },
                      { value: $formData.notes }
                    ),
                    {
                      value: ($$value) => {
                        $formData.notes = $$value;
                        $$settled = false;
                      }
                    },
                    {}
                  )}`;
                }
              })} ${validate_component(Form_field_errors, "Form.FieldErrors").$$render($$result, {}, {}, {})}`;
            }
          }
        )}</div> ${validate_component(Separator, "Separator").$$render($$result, {}, {}, {})}  <div class="mx-16 flex"><input type="text" readonly class="w-full rounded-md border-2 border-slate-500 px-3 py-1 text-sm placeholder-slate-600"${add_attribute("placeholder", `MPG: ${mpg}`, 0)}> <input type="text" class="w-full rounded-md border-2 border-slate-500 px-3 py-1 text-sm placeholder-slate-600"${add_attribute("placeholder", `PPG: ${ppg}`, 0)}></div> <div class="my-4 text-center">${validate_component(Form_button, "Form.Button").$$render(
          $$result,
          {
            class: "w-1/2 font-bold uppercase text-white " + (isSuccess ? "bg-emerald-700" : "bg-sky-700"),
            disabled: isSuccess
          },
          {},
          {
            default: () => {
              return `${escape(isSuccess ? "sent!" : "submit")}`;
            }
          }
        )}</div></form>`;
      }
    })}</div> ${validate_component(Sonner_1, "Toaster").$$render($$result, { richColors: true }, {}, {})}`;
  } while (!$$settled);
  $$unsubscribe_formData();
  return $$rendered;
});
export {
  Page as default
};
