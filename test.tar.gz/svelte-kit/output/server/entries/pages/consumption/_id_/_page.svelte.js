import { c as create_ssr_component, b as add_attribute, d as escape, v as validate_component, e as each } from "../../../../chunks/ssr.js";
import { C as CarSource } from "../../../../chunks/CarSource.js";
import { Chart, Tooltip, Legend, LineElement, LinearScale, PointElement, CategoryScale, LineController, Filler } from "chart.js";
import { C as Card } from "../../../../chunks/Card.js";
const fontColor = "#e2e8f0";
const ConsumptionChart = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  Chart.register(Tooltip, Legend, LineElement, LinearScale, PointElement, CategoryScale, LineController, Filler);
  let { chartData } = $$props;
  let { selectedChart } = $$props;
  let myCanvas;
  const chartTypes = {
    ppg: {
      label: "Price Per Gallon",
      datapoint: "price_per_gallon",
      radius: 0,
      fill: true
    },
    mpg: {
      label: "Miles Per Gallon",
      datapoint: "miles_per_gallon",
      radius: 5,
      fill: false
    }
  };
  if ($$props.chartData === void 0 && $$bindings.chartData && chartData !== void 0)
    $$bindings.chartData(chartData);
  if ($$props.selectedChart === void 0 && $$bindings.selectedChart && selectedChart !== void 0)
    $$bindings.selectedChart(selectedChart);
  ({
    labels: chartData.map((o) => new Date(o.created).toISOString().split("T")[0]).reverse(),
    datasets: [
      {
        label: chartTypes[selectedChart].label,
        data: chartData.map((o) => parseFloat(o[chartTypes[selectedChart].datapoint].toFixed(2))).reverse(),
        backgroundColor: "#0369a1",
        //sky-700
        // backgroundColor: "#6d28d9", //violet-700
        borderColor: fontColor,
        fill: chartTypes[selectedChart].fill,
        radius: chartTypes[selectedChart].radius
      }
    ]
  });
  return `<div class="bg-slate-800 rounded relative w-full h-80">${chartData.length === 0 ? `<h6 data-svelte-h="svelte-8zme4v">No Chart Data...</h6>` : `<canvas${add_attribute("this", myCanvas, 0)}></canvas>`}</div>`;
});
const SummaryItem = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { key } = $$props;
  let { value } = $$props;
  if ($$props.key === void 0 && $$bindings.key && key !== void 0)
    $$bindings.key(key);
  if ($$props.value === void 0 && $$bindings.value && value !== void 0)
    $$bindings.value(value);
  return `<div class="bg-gray-700 text-slate-100 mx-4 my-3 p-3 rounded-lg"><small class="mr-2 font-light text-slate-300">${escape(key)}</small> <b>${escape(value)}</b></div>`;
});
const ConsumptionSummary = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { summary } = $$props;
  const roundTwoDecimals = {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  };
  const roundZeroDecimals = {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  };
  if ($$props.summary === void 0 && $$bindings.summary && summary !== void 0)
    $$bindings.summary(summary);
  return `${validate_component(Card, "Card").$$render($$result, { header: "summary" }, {}, {
    default: () => {
      return `${summary.total_miles === null ? `<h6 data-svelte-h="svelte-1uubvif">No Summary Data...</h6>` : `<div class="text-center">${validate_component(SummaryItem, "SummaryItem").$$render(
        $$result,
        {
          key: "Total Miles",
          value: summary.total_miles.toLocaleString(void 0, roundZeroDecimals)
        },
        {},
        {}
      )} ${validate_component(SummaryItem, "SummaryItem").$$render(
        $$result,
        {
          key: "Total Cost:",
          value: "$" + summary.total_price.toLocaleString(void 0, roundZeroDecimals)
        },
        {},
        {}
      )} ${validate_component(SummaryItem, "SummaryItem").$$render(
        $$result,
        {
          key: "Total Miles per Gallon:",
          value: summary.total_miles_per_gallon.toLocaleString(void 0, roundTwoDecimals)
        },
        {},
        {}
      )} ${validate_component(SummaryItem, "SummaryItem").$$render(
        $$result,
        {
          key: "Total Cost per Gallon:",
          value: "$" + summary.total_price_per_gallon.toLocaleString(void 0, roundTwoDecimals)
        },
        {},
        {}
      )}</div>`}`;
    }
  })}`;
});
const MileageData = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { tableRows } = $$props;
  if ($$props.tableRows === void 0 && $$bindings.tableRows && tableRows !== void 0)
    $$bindings.tableRows(tableRows);
  return `${validate_component(Card, "Card").$$render($$result, { header: "mileage data" }, {}, {
    default: () => {
      return `${tableRows.length === 0 ? `<h6 data-svelte-h="svelte-11rixgv">No Data...</h6>` : `<div class="px-4 py-4 overflow-x-auto"><table class="w-full table-auto"><thead class="border-b-2 border-white font-bold text-slate-100" data-svelte-h="svelte-swm8o4"><tr class="text-left"><th>Date</th> <th>Miles/Gallon</th> <th>Price/Gallon</th> <th>Notes</th></tr></thead> <tbody>${each(tableRows, (row) => {
        return `<tr class="text-left text-sm transition duration-300 ease-in-out font-normal hover:bg-gray-500 border-b border-gray-500 text-slate-300"><td>${escape(new Date(row.created).toISOString().split("T")[0])}</td> <td>${escape(row.miles_per_gallon.toFixed(2))}</td> <td>$${escape(row.price_per_gallon.toFixed(2))}</td> <td>${escape(row.notes === null ? "" : row.notes)}</td> </tr>`;
      })}</tbody></table></div>`}`;
    }
  })}`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  return `${$$result.head += `<!-- HEAD_svelte-15zmvdu_START -->${$$result.title = `<title>Consumption</title>`, ""}<meta name="description" content="automobile consumption"><!-- HEAD_svelte-15zmvdu_END -->`, ""} <div class="container mx-auto">${validate_component(CarSource, "CarSource").$$render($$result, { cars: data.cars }, {}, {})} <div class="mb-2 gap-4 md:flex"><div class="md:basis-4/12">${validate_component(ConsumptionSummary, "ConsumptionSummary").$$render($$result, { summary: data.summary }, {}, {})}</div> <div class="md:basis-8/12">${validate_component(MileageData, "MileageData").$$render($$result, { tableRows: data.consumption.slice(0, 7) }, {}, {})}</div></div> <div class="hidden md:inline">${validate_component(ConsumptionChart, "ConsumptionChart").$$render(
    $$result,
    {
      chartData: data.consumption,
      selectedChart: "mpg"
    },
    {},
    {}
  )} <br> ${validate_component(ConsumptionChart, "ConsumptionChart").$$render(
    $$result,
    {
      chartData: data.consumption,
      selectedChart: "ppg"
    },
    {},
    {}
  )}</div></div>`;
});
export {
  Page as default
};
