import { e as error } from "../../../../chunks/index.js";
import { c as client, h as GET_CARS_OWNED, i as GET_SUMMARY, j as GET_CONSUMPTION } from "../../../../chunks/queries.js";
const load = async ({ params }) => {
  try {
    const carId = parseInt(params.id);
    const rs = await client.batch(
      [
        GET_CARS_OWNED,
        {
          sql: GET_SUMMARY,
          args: { carId }
        },
        {
          sql: GET_CONSUMPTION,
          args: { carId }
        }
      ],
      "read"
    );
    const cars = rs[0].rows;
    const summary = rs[1].rows[0];
    const consumption = rs[2].rows;
    return {
      cars,
      summary,
      consumption
    };
  } catch (e) {
    error(505, e.message);
  }
};
export {
  load
};
