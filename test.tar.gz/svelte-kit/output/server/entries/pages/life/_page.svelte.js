import { c as create_ssr_component, d as escape, e as each } from "../../../chunks/ssr.js";
const css = {
  code: ".row.svelte-bm4vbd{display:flex}.square.svelte-bm4vbd{border:1px solid gray;height:26px;width:26px}.center.svelte-bm4vbd{justify-content:center;display:grid;margin-top:2em}.gen.svelte-bm4vbd{justify-content:center;display:grid;margin-top:1em}",
  map: null
};
let GRID_SIZE = 30;
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let grid = new Array(GRID_SIZE).fill(0).map((e) => new Array(GRID_SIZE));
  let generation = 0;
  $$result.css.add(css);
  return `${$$result.head += `<!-- HEAD_svelte-3qs0gy_START -->${$$result.title = `<title>Life</title>`, ""}<meta name="description" content="Game of life"><!-- HEAD_svelte-3qs0gy_END -->`, ""} <div class="container mx-auto"><button class="btn bg-cyan-600 text-sm mt-4 border mr-2" data-svelte-h="svelte-1avzoyk">Random Generator!</button> <button class="btn bg-cyan-600 text-sm mt-4 border mr-2" data-svelte-h="svelte-1eebi2f">Toad</button> <button class="btn bg-cyan-600 text-sm mt-4 border mr-2" data-svelte-h="svelte-mbsyy9">Blinker</button> <button class="btn bg-cyan-600 text-sm mt-4 border mr-2" data-svelte-h="svelte-1hfalyc">Penta-Decathlon</button> ${`<button class="btn bg-cyan-600 text-sm mt-4 border mr-2" data-svelte-h="svelte-1p1y4s0">Pause</button>`} <h2 class="gen svelte-bm4vbd">Generation: ${escape(generation)}</h2> <hr> <div class="center svelte-bm4vbd">${each(grid, (row) => {
    return `<div class="row svelte-bm4vbd">${each(row, (cell) => {
      return `<div class="${["square svelte-bm4vbd", cell === 1 ? "bg-red-700" : ""].join(" ").trim()}"></div>`;
    })} </div>`;
  })}</div> </div>`;
});
export {
  Page as default
};
