import { c as create_ssr_component, v as validate_component, a as subscribe, e as each, b as add_attribute, d as escape } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
import { I as Icon } from "../../chunks/Icon.js";
/* empty css               */
const Terminal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const iconNode = [
    ["polyline", { "points": "4 17 10 11 4 5" }],
    [
      "line",
      {
        "x1": "12",
        "x2": "20",
        "y1": "19",
        "y2": "19"
      }
    ]
  ];
  return `${validate_component(Icon, "Icon").$$render($$result, Object.assign({}, { name: "terminal" }, $$props, { iconNode }), {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});
const Terminal$1 = Terminal;
const Navbar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  const routes = [
    { location: "/", description: "Home" },
    {
      location: "/consumption/4",
      description: "Consumption"
    },
    { location: "/books", description: "Books" },
    {
      location: "/yields",
      description: "Yields"
    },
    { location: "/cars/3", description: "Cars" },
    { location: "/snake", description: "Snake" },
    { location: "/life", description: "Life" }
  ];
  $page.url.pathname;
  $$unsubscribe_page();
  return `<nav class="flex items-center justify-between space-x-4 bg-zinc-800 px-4 py-3 lg:space-x-6"><div><a href="/">${validate_component(Terminal$1, "Terminal").$$render($$result, {}, {}, {})}</a></div> <div class="flex space-x-4 lg:space-x-6">${each(routes, ({ location, description }) => {
    return `<a class="hover:text-primary text-sm font-medium transition-colors"${add_attribute("href", location, 0)}>${escape(description)}</a>`;
  })}</div></nav>`;
});
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Navbar, "Navbar").$$render($$result, {}, {}, {})} ${slots.default ? slots.default({}) : ``}`;
});
export {
  Layout as default
};
