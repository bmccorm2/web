import { G as GET_CAR_DETAILS } from "../../../../chunks/queries_graphql.js";
import { G as GRAPHQL_URL } from "../../../../chunks/private.js";
const load = async ({ fetch, params }) => {
  const carId = parseInt(params.id);
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json"
  };
  const query = {
    query: GET_CAR_DETAILS,
    variables: { carId }
  };
  const options = {
    method: "POST",
    headers,
    body: JSON.stringify(query)
  };
  const res = await fetch(GRAPHQL_URL, options);
  const {
    data: { cars, carDetails }
  } = await res.json();
  return { cars, carDetails };
};
export {
  load
};
