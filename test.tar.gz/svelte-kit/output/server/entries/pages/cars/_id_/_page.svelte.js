import { c as create_ssr_component, b as add_attribute, d as escape, v as validate_component } from "../../../../chunks/ssr.js";
import { C as CarSource } from "../../../../chunks/CarSource.js";
import { Chart, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement, ScatterController } from "chart.js";
const css = {
  code: ".hideDetails.svelte-wpzi8x{display:none}.smallChart.svelte-wpzi8x{width:75%}.bold.svelte-wpzi8x{font-weight:bolder}",
  map: null
};
const CarChart = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  Chart.register(Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement, ScatterController);
  let { chartData } = $$props;
  let url;
  let displayName;
  let year;
  let effectiveDate;
  const colors = ["maroon", "blue", "green", "orange", "purple", "pink"];
  const years = [...new Set(chartData.map((o) => o.year))];
  if ($$props.chartData === void 0 && $$bindings.chartData && chartData !== void 0)
    $$bindings.chartData(chartData);
  $$result.css.add(css);
  ({
    datasets: years.map((year2, index) => {
      return {
        label: year2.toString(),
        backgroundColor: colors[index],
        data: chartData.filter((o) => o.year === year2).map((o) => {
          return {
            x: o.price,
            y: o.miles,
            price: o.price,
            miles: o.miles,
            url: o.url,
            displayName: o.displayName,
            year: o.year,
            effectiveDate: new Date(o.effectiveDate).toISOString().split("T")[0],
            distance: o.distance
          };
        }),
        radius: 8
      };
    })
  });
  return `<div class="${["col-12 svelte-wpzi8x", ""].join(" ").trim()}" data-svelte-h="svelte-rrc9pt"></div> <div class="${["col-3 svelte-wpzi8x", "hideDetails"].join(" ").trim()}"><div class="card" data-svelte-h="svelte-so3y38"><div class="card-header text-center-fs-4">Details</div></div> <div class="card-body"><p class="fw-bolder"><a${add_attribute("href", url, 0)} target="_blank" rel="noopener noreferrer">${escape(displayName)}</a></p> <p class="bold svelte-wpzi8x"><small data-svelte-h="svelte-1garrzz">Price:</small> 
			${escape("")}</p> <p class="bold svelte-wpzi8x"><small data-svelte-h="svelte-niyhg0">Miles:</small> 
			${escape("")}</p> <p class="bold svelte-wpzi8x"><small data-svelte-h="svelte-6pc8hj">Year:</small> ${escape(year)}</p> <p class="bold svelte-wpzi8x"><small data-svelte-h="svelte-zu1hia">Distance (mi):</small> 
			${escape("")}</p> <p class="bold svelte-wpzi8x"><small data-svelte-h="svelte-dwmx45">Last Updated:</small> 
			${escape(effectiveDate)}</p></div> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  const { cars, carDetails } = data;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  return `${$$result.head += `<!-- HEAD_svelte-ktgtri_START -->${$$result.title = `<title>Cars</title>`, ""}<meta name="description" content="price to mileage charting"><!-- HEAD_svelte-ktgtri_END -->`, ""} <div class="container mx-auto">${validate_component(CarSource, "CarSource").$$render($$result, { cars }, {}, {})} ${validate_component(CarChart, "CarChart").$$render($$result, { chartData: carDetails }, {}, {})}</div>`;
});
export {
  Page as default
};
