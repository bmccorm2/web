import { a as GET_YIELDS } from "../../../chunks/queries_graphql.js";
import { G as GRAPHQL_URL } from "../../../chunks/private.js";
import { e as error } from "../../../chunks/index.js";
const load = async ({ fetch }) => {
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json"
  };
  const query = {
    query: GET_YIELDS
  };
  const options = {
    method: "POST",
    headers,
    body: JSON.stringify(query)
  };
  const res = await fetch(GRAPHQL_URL, options);
  const {
    data: { yields }
  } = await res.json();
  if (yields && yields.length != 3)
    error(505, "Insufficient data.");
  return { yields };
};
export {
  load
};
