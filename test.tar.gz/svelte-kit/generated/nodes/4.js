export { default as component } from "../../../src/routes/consumption/[id]/+page.svelte";
export const server = true;