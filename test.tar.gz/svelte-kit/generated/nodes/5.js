export { default as component } from "../../../src/routes/consumption/input/+page.svelte";
export const server = true;