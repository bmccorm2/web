export { default as component } from "../../../src/routes/yields/+page.svelte";
export const server = true;