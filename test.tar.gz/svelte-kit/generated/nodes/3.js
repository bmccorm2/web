export { default as component } from "../../../src/routes/cars/[id]/+page.svelte";
export const server = true;