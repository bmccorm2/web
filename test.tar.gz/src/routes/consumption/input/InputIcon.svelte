<span
   class="flex content-center rounded-l-md border border-white bg-gray-500 px-4 py-1"
>
   <slot />
</span>
