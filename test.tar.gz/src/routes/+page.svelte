<svelte:head>
	<title>Home</title>
	<meta name="description" content="Home Page" />
</svelte:head>
