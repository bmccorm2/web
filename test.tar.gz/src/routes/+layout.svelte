<script>
  import Navbar from "$lib/Navbar.svelte";
  import "../app.pcss";
</script>

<Navbar />
<slot />
