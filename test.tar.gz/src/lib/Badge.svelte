<script lang="ts">
  export let text = "Default";
</script>

<div class="px-4 py-2 rounded-lg">
  {text}
</div>
