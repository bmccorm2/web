import Root from "./checkbox.svelte";
export {
	Root,
	//
	Root as Checkbox,
};
