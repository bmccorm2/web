import { writable } from "svelte/store";

export const userRating = writable(0);
