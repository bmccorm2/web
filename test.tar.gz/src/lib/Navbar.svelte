<script lang="ts">
   import { page } from "$app/stores";
   import { Terminal } from "lucide-svelte";

   $: activeUrl = $page.url.pathname;

   const routes = [
      {
         location: "/",
         description: "Home",
      },
      {
         location: "/consumption/4",
         description: "Consumption",
      },
      {
         location: "/books",
         description: "Books",
      },
      {
         location: "/yields",
         description: "Yields",
      },
      {
         location: "/cars/3",
         description: "Cars",
      },
      {
         location: "/snake",
         description: "Snake",
      },
      {
         location: "/life",
         description: "Life",
      },
   ];

   const activeClass = "md:border-b-4 border-white";
</script>

<nav
   class="flex items-center justify-between space-x-4 bg-zinc-800 px-4 py-3 lg:space-x-6"
>
   <div>
      <a href="/">
         <Terminal />
      </a>
   </div>
   <div class="flex space-x-4 lg:space-x-6">
      {#each routes as { location, description }}
         <a
            class="hover:text-primary text-sm font-medium transition-colors"
            href={location}>{description}</a
         >
      {/each}
   </div>
</nav>
