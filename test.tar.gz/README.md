# create-svelte

Everything you need to build a Svelte project, powered by [`create-svelte`](https://github.com/sveltejs/kit/tree/master/packages/create-svelte).

## Deploying

-  make sure to copy the db file from prod -> dev because the docker build command will package it up.
-  run docker build locally, then push to prod
